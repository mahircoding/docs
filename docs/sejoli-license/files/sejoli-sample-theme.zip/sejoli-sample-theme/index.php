<?php
/**
 * The main template file.
 *
 * This theme doesn't output anything.  It just show how SEJOLI licensing works.
 *
 * @package WordPress
 * @subpackage SEJOLI Sample Theme
 */
?>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<title>SEJOLI Sample Theme</title>
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

	<article>
		<h1>SEJOLI Sample Theme</h1>
		<p>Licensing for your WordPress Themes</p>
	</article>

<?php wp_footer(); ?>

</body>
</html>